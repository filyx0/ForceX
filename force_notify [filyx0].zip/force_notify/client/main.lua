RegisterNetEvent("force_notify:notify")
AddEventHandler("force_notify:notify", function(title, text, duration)
  notify(title, text, duration)
end)

function notify(title, text, duration)
  SendNUIMessage({
    action = "notify",
    data = {
      title = title,
      text = text,
      duration = duration
    }
  })
end

RegisterCommand("notify", function()
  notify("Force X", "La mamma di quel porcoddio di loupass sborrata nell'ano dio cum")
end, false)