fx_version "bodacious"
game "gta5"

author "filyx0"
description "Force Notify"
version "1.0.0"

client_scripts {
    "client/*.lua"
}

ui_page "html/index.html"

files{
    "html/**.**",
    "html/assets/**"
}

export "notify"