Config = {}

Config.Command = "documents"
Config.RegisterKey = nil

Config.DocumentItemName = nil
Config.BirthdateFormat = "DD/MM/YYYY"

Config.PaperProp = {
  name = "prop_cd_paper_pile1",
  xRot = -130.0, 
	yRot = -50.0, 
	zRot = 0.0
}

Config.Locale = {
  ["receiveNotification"] = "You received a document: ",
  ["giveNotification"] = "You gave a document: ",
  ["cancel"] = "Cancel",
  ["noPlayersAround"] = "There's no one around you",
  ["showDocument"] = "Show Document",
  ["giveCopy"] = "Give Copy",
  ["registerMapDescription"] = "Open documents"
}